package notification;

public interface NotificationService {
    void sendNotification(String message);
}
