package model;

public enum EventType {
    CONCERT,
    CONFERENCE,
    WORKSHOP
}
