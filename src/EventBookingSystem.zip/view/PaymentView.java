package view;

/**
 * View for displaying payment information.
 */
public class PaymentView {
    public void displayPaymentConfirmation(double amount) {
        System.out.println("Payment of " + amount + " has been processed successfully.");
    }
}
